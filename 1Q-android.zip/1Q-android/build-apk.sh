#!/usr/bin/env bash
# Builds 1Q.apk on macOS or Linux using only public downloads:
#   - Android command-line tools + SDK from dl.google.com
#   - Gradle 8.7 from services.gradle.org
#   - Android Gradle Plugin and libraries from Google Maven / Maven Central
# Everything is kept inside ./.tools so nothing on your system is changed.
# Requirements: Java 17 (e.g. Temurin 17), curl, unzip.
set -euo pipefail

DIR="$(cd "$(dirname "$0")" && pwd)"
TOOLS="$DIR/.tools"
GRADLE_VERSION="8.7"
CMDLINE_BUILD="11076708"
mkdir -p "$TOOLS"

say(){ printf "\n\033[1;33m▸ %s\033[0m\n" "$*"; }
fail(){ printf "\n\033[1;31m✕ %s\033[0m\n" "$*" >&2; exit 1; }

# ---- Java 17+ -------------------------------------------------------------
command -v java >/dev/null 2>&1 || fail "Java not found. Install JDK 17 (https://adoptium.net) and run again."
JV=$(java -version 2>&1 | head -n1 | sed -E 's/.*version "([0-9]+).*/\1/')
[ "${JV:-0}" -ge 17 ] 2>/dev/null || fail "Java 17 or newer is required (found: $(java -version 2>&1 | head -n1))."
for t in curl unzip; do command -v $t >/dev/null 2>&1 || fail "'$t' is required. Please install it and run again."; done

# ---- Android SDK ----------------------------------------------------------
case "$(uname -s)" in
  Darwin) OS=mac ;;
  Linux)  OS=linux ;;
  *) fail "Unsupported system. On Windows use build-apk.ps1." ;;
esac

SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-$TOOLS/android-sdk}}"
SDKMANAGER="$SDK/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKMANAGER" ]; then
  say "Downloading Android command-line tools"
  mkdir -p "$SDK/cmdline-tools"
  curl -fL --retry 3 -o "$TOOLS/cmdline-tools.zip" \
    "https://dl.google.com/android/repository/commandlinetools-${OS}-${CMDLINE_BUILD}_latest.zip"
  rm -rf "$SDK/cmdline-tools/latest" "$TOOLS/cmdline-tools-tmp"
  unzip -q "$TOOLS/cmdline-tools.zip" -d "$TOOLS/cmdline-tools-tmp"
  mv "$TOOLS/cmdline-tools-tmp/cmdline-tools" "$SDK/cmdline-tools/latest"
  rm -rf "$TOOLS/cmdline-tools-tmp" "$TOOLS/cmdline-tools.zip"
fi

if [ ! -d "$SDK/platforms/android-34" ] || [ ! -d "$SDK/build-tools/34.0.0" ]; then
  say "Installing Android SDK 34 (accepting the Android SDK licences)"
  yes | "$SDKMANAGER" --sdk_root="$SDK" --licenses >/dev/null || true
  "$SDKMANAGER" --sdk_root="$SDK" "platform-tools" "platforms;android-34" "build-tools;34.0.0"
fi
echo "sdk.dir=$SDK" > "$DIR/local.properties"

# ---- Gradle ---------------------------------------------------------------
GRADLE="$(command -v gradle || true)"
if [ -z "$GRADLE" ] || ! "$GRADLE" --version 2>/dev/null | grep -qE "Gradle (8\.([7-9]|[1-9][0-9])|9\.)"; then
  GRADLE="$TOOLS/gradle-$GRADLE_VERSION/bin/gradle"
  if [ ! -x "$GRADLE" ]; then
    say "Downloading Gradle $GRADLE_VERSION"
    curl -fL --retry 3 -o "$TOOLS/gradle.zip" "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
    unzip -q "$TOOLS/gradle.zip" -d "$TOOLS"
    rm -f "$TOOLS/gradle.zip"
  fi
fi

# ---- Build ----------------------------------------------------------------
say "Building 1Q (first run downloads the Android Gradle Plugin — a few minutes)"
export ANDROID_HOME="$SDK" ANDROID_SDK_ROOT="$SDK"
"$GRADLE" -p "$DIR" :app:assembleRelease --no-daemon

APK="$DIR/app/build/outputs/apk/release/app-release.apk"
[ -f "$APK" ] || fail "Build finished but no APK was found."
cp "$APK" "$DIR/1Q.apk"
printf "\n\033[1;32m✓ Done: %s\033[0m\n" "$DIR/1Q.apk"
echo "  Copy it to your phone and open it, or with a phone connected run:"
echo "  \"$SDK/platform-tools/adb\" install -r \"$DIR/1Q.apk\""
