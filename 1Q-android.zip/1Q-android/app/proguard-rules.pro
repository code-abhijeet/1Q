-keepclassmembers class com.oneq.app.MainActivity$Bridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.oneq.app.MainActivity$Bridge { *; }
