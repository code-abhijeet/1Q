package com.oneq.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.webkit.WebViewAssetLoader;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * 1Q runs the bundled web app from a fixed https origin
 * (appassets.androidplatform.net) so localStorage — and with it all
 * progress, notes and settings — is kept between launches.
 *
 * Stability:
 *  - If the WebView's rendering process dies (low memory / GPU driver),
 *    the page is rebuilt in a lighter mode instead of the app crashing.
 *  - Any crash is saved and shown on the next launch so it can be copied
 *    and reported.
 */
public class MainActivity extends Activity {

    private static final String TAG = "1Q";
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + HOST + "/assets/index.html";
    private static final int DARK = Color.parseColor("#050608");
    private static final int LIGHT = Color.parseColor("#E9EBEE");
    private static final String PREFS = "oneq_app";

    private FrameLayout root;
    private WebView web;
    private WebViewAssetLoader loader;
    private boolean lite;
    private int renderRestarts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        installCrashRecorder(this);
        super.onCreate(savedInstanceState);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        lite = p.getBoolean("lite", false);

        root = new FrameLayout(this);
        root.setBackgroundColor(DARK);
        setContentView(root);
        applyBars(false);

        try {
            loader = new WebViewAssetLoader.Builder()
                    .setDomain(HOST)
                    .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                    .build();
            createWebView(savedInstanceState);
        } catch (Throwable t) {
            // Usually: Android System WebView is missing, disabled or updating.
            Log.e(TAG, "WebView unavailable", t);
            showMessage("1Q needs Android System WebView.\n\nOpen Google Play, update \u201cAndroid System WebView\u201d"
                    + " (and Chrome), then open 1Q again.\n\n" + t);
        }

        showPreviousCrashIfAny();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void createWebView(Bundle state) {
        web = new WebView(this);
        web.setBackgroundColor(DARK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage = saved progress
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportMultipleWindows(false);    // window.open() goes through shouldOverrideUrlLoading
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (HOST.equals(uri.getHost())) return false;  // stay inside the app
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));  // e.g. LeetCode links
                } catch (ActivityNotFoundException ignored) { }
                return true;
            }

            /** Without this, a dead renderer (out of memory / GPU) kills the whole app. */
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                Log.e(TAG, "Renderer gone, crashed=" + (Build.VERSION.SDK_INT >= 26 && detail.didCrash()));
                recoverFromRendererLoss();
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "OneQAndroid");

        if (state != null && web.restoreState(state) != null) return;
        web.loadUrl(START_URL);
    }

    private void recoverFromRendererLoss() {
        renderRestarts++;
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        // Switch to the lighter visual mode and remember it for next launches.
        lite = true;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("lite", true).apply();
        if (renderRestarts > 2) {
            showMessage("1Q could not keep the page running on this device.\n\n"
                    + "Please update \u201cAndroid System WebView\u201d and Chrome from Google Play, then open 1Q again.");
            return;
        }
        createWebView(null);
    }

    /** Called from the page. */
    final class Bridge {
        @JavascriptInterface
        public void setTheme(final String theme) {
            runOnUiThread(() -> applyBars("light".equals(theme)));
        }

        @JavascriptInterface
        public boolean isLite() {
            return lite;
        }

        @JavascriptInterface
        public void setLite(final boolean on) {
            lite = on;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("lite", on).apply();
        }
    }

    @SuppressWarnings("deprecation")
    private void applyBars(boolean light) {
        try {
            Window w = getWindow();
            int c = light ? LIGHT : DARK;
            w.setStatusBarColor(c);
            w.setNavigationBarColor(c);
            if (root != null) root.setBackgroundColor(c);
            if (web != null) web.setBackgroundColor(c);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                WindowInsetsController ic = w.getInsetsController();
                if (ic != null) {
                    int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                    ic.setSystemBarsAppearance(light ? mask : 0, mask);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                View d = w.getDecorView();
                int flags = d.getSystemUiVisibility();
                flags = light ? (flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR)
                              : (flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    flags = light ? (flags | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
                                  : (flags & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
                }
                d.setSystemUiVisibility(flags);
            }
        } catch (Throwable t) {
            Log.w(TAG, "System bar styling skipped", t);
        }
    }

    private void showMessage(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(Color.parseColor("#E8EEF6"));
        tv.setTextSize(15);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(56, 56, 56, 56);
        tv.setTextIsSelectable(true);
        root.removeAllViews();
        root.addView(tv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    // ---------------------------------------------------------------- crash report

    private static void installCrashRecorder(Context ctx) {
        final Context app = ctx.getApplicationContext();
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        if (previous instanceof Recorder) return;
        Thread.setDefaultUncaughtExceptionHandler(new Recorder(app, previous));
    }

    private static final class Recorder implements Thread.UncaughtExceptionHandler {
        private final Context app;
        private final Thread.UncaughtExceptionHandler previous;

        Recorder(Context app, Thread.UncaughtExceptionHandler previous) {
            this.app = app;
            this.previous = previous;
        }

        @Override
        public void uncaughtException(Thread t, Throwable e) {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String report = "1Q " + BuildInfo.version(app) + " · Android " + Build.VERSION.RELEASE
                        + " (API " + Build.VERSION.SDK_INT + ") · " + Build.MANUFACTURER + " " + Build.MODEL
                        + "\n\n" + sw;
                app.getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("last_crash", report).commit();
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(t, e);
        }
    }

    private static final class BuildInfo {
        static String version(Context c) {
            try {
                return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
            } catch (Throwable t) {
                return "?";
            }
        }
    }

    private void showPreviousCrashIfAny() {
        final SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        final String report = p.getString("last_crash", null);
        if (report == null) return;
        p.edit().remove("last_crash").apply();
        try {
            new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                    .setTitle("1Q closed unexpectedly last time")
                    .setMessage("Copy this report and share it so the problem can be fixed.\n\n"
                            + (report.length() > 3500 ? report.substring(0, 3500) + "\n…" : report))
                    .setPositiveButton("Copy report", (d, w) -> {
                        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("1Q crash report", report));
                    })
                    .setNegativeButton("Close", null)
                    .show();
        } catch (Throwable ignored) { }
    }

    // ---------------------------------------------------------------- lifecycle

    /** Back moves through the app's own pages first, then leaves the app. */
    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            root.removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
