# 1Q — Android app

This folder is a complete Android project that wraps the 1Q web app
(`app/src/main/assets/index.html`) in a fast, full-screen native shell.

**What you get**
- Opens with the 1Q launch animation: the mark glows in, zooms out into the
  header logo, and the Home page rises in.
- Progress, notes, streaks, theme and motion settings are saved on the phone
  and restored on every launch (and included in Android device backups).
- Status and navigation bars follow the app's dark / light theme.
- Android back button moves through the app's pages before leaving.
- Problem links (LeetCode) open in the phone's browser.
- Release build is minified and shrunk; min Android 7.0 (API 24).

## Build the APK

### Option A — Android Studio (simplest)
1. Install Android Studio (Koala or newer).
2. **File → Open…** and pick this folder. Let Gradle sync finish.
3. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Click **locate** in the notification. The file is
   `app/build/outputs/apk/debug/app-debug.apk` (or `release/app-release.apk`
   for **Build → Generate Signed App Bundle / APK…**).

### Option B — command line
Requires JDK 17, the Android SDK (`ANDROID_HOME` set) and Gradle 8.7:

    gradle :app:assembleRelease

Output: `app/build/outputs/apk/release/app-release.apk`

### Option C — CI
`.github/workflows/build-apk.yml` builds the APK on every push and attaches
`1Q.apk` as a downloadable artifact. Use it in a repository your organisation
allows for this code.

## Install on a phone
Copy the APK to the phone and open it. Android will ask once to allow
installs from that source (Settings → Apps → Special access → Install unknown
apps).

## Signing
The release build is signed with the local debug key so it installs straight
away. Before sharing widely or publishing to Google Play, create your own
keystore and set a `signingConfig` in `app/build.gradle`.

## Updating the app
Replace `app/src/main/assets/index.html` with a newer export and bump
`versionCode` / `versionName` in `app/build.gradle`. Saved progress is kept
across updates because the app always loads from the same origin.
