# 1Q — Android app

This folder is a complete Android project that wraps the 1Q web app
(`app/src/main/assets/index.html`) in a fast, full-screen native shell.

**What you get**
- Opens with the 1Q launch animation: the mark glows in, zooms out into the
  header logo, and the Home page rises in.
- Progress, notes, streaks, theme and motion settings are saved on the phone
  and restored on every launch (and included in Android device backups).
- Status and navigation bars follow the app's dark / light theme.
- Android back button moves through the app's pages before leaving.
- Problem links (LeetCode) open in the phone's browser.
- Release build is minified and shrunk; min Android 7.0 (API 24).

## Build the APK

Everything comes from public sources: Google's Android servers, Maven Central and
Gradle's own site. No company registry or login is involved.

### Option A — one command (no Android Studio needed)
You only need **Java 17** installed (for example Temurin 17 from https://adoptium.net).

**macOS / Linux**

    ./build-apk.sh

**Windows (PowerShell)**

    powershell -ExecutionPolicy Bypass -File build-apk.ps1

The script downloads the Android command-line tools, the Android 34 SDK and
Gradle 8.7 into a local `.tools` folder, accepts the Android SDK licences, builds
the app and leaves **`1Q.apk`** in this folder. The first run takes a few minutes;
later runs reuse the downloads. Delete `.tools` to remove everything again.

### Option B — Android Studio
1. **File → Open…** and pick this folder. Let Gradle sync finish.
2. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**, then **locate**.

### Option C — CI
`.github/workflows/build-apk.yml` builds `1Q.apk` on every push and attaches it as
a downloadable artifact.

## Install on a phone
Copy the APK to the phone and open it. Android will ask once to allow
installs from that source (Settings → Apps → Special access → Install unknown
apps).

## Signing
The release build is signed with the local debug key so it installs straight
away. Before sharing widely or publishing to Google Play, create your own
keystore and set a `signingConfig` in `app/build.gradle`.

## Updating the app
Replace `app/src/main/assets/index.html` with a newer export and bump
`versionCode` / `versionName` in `app/build.gradle`. Saved progress is kept
across updates because the app always loads from the same origin.

## If the app closes or crashes
Version 1.1 adds three safety nets:
- If Android's WebView rendering process runs out of memory, 1Q rebuilds the
  page in a lighter visual mode instead of closing, and remembers that mode.
- Any crash is saved and shown the next time you open 1Q, with a
  **Copy report** button — please share that text.
- Code shrinking (R8) is switched off, a frequent cause of start-up crashes.

Also make sure **Android System WebView** and **Chrome** are up to date in
Google Play — 1Q draws its screens with them.

To capture a live log (optional), connect the phone with USB debugging on and run:

    adb logcat -c && adb logcat | grep -iE "1Q|AndroidRuntime|chromium"

then open the app and copy the lines printed when it closes.
