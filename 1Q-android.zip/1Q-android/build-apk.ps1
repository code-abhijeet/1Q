# Builds 1Q.apk on Windows using only public downloads:
#   - Android command-line tools + SDK from dl.google.com
#   - Gradle 8.7 from services.gradle.org
#   - Android Gradle Plugin and libraries from Google Maven / Maven Central
# Everything is kept inside .\.tools so nothing on your system is changed.
# Requirement: Java 17 (e.g. Temurin 17).
# Run:  powershell -ExecutionPolicy Bypass -File build-apk.ps1
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$Dir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$Tools = Join-Path $Dir ".tools"
$GradleVersion = "8.7"
$CmdlineBuild  = "11076708"
New-Item -ItemType Directory -Force -Path $Tools | Out-Null

function Say($m)  { Write-Host "`n> $m" -ForegroundColor Yellow }
function Fail($m) { Write-Host "`nX $m" -ForegroundColor Red; exit 1 }

# ---- Java 17+ -------------------------------------------------------------
$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) { Fail "Java not found. Install JDK 17 (https://adoptium.net) and run again." }
$verLine = (& java -version 2>&1 | Select-Object -First 1).ToString()
if ($verLine -match 'version "(\d+)') { $jv = [int]$Matches[1] } else { $jv = 0 }
if ($jv -lt 17) { Fail "Java 17 or newer is required (found: $verLine)." }

# ---- Android SDK ----------------------------------------------------------
$Sdk = $env:ANDROID_HOME
if (-not $Sdk) { $Sdk = $env:ANDROID_SDK_ROOT }
if (-not $Sdk) { $Sdk = Join-Path $Tools "android-sdk" }
$SdkManager = Join-Path $Sdk "cmdline-tools\latest\bin\sdkmanager.bat"
if (-not (Test-Path $SdkManager)) {
  Say "Downloading Android command-line tools"
  $zip = Join-Path $Tools "cmdline-tools.zip"
  $tmp = Join-Path $Tools "cmdline-tools-tmp"
  Invoke-WebRequest "https://dl.google.com/android/repository/commandlinetools-win-$($CmdlineBuild)_latest.zip" -OutFile $zip
  if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
  Expand-Archive $zip -DestinationPath $tmp
  New-Item -ItemType Directory -Force -Path (Join-Path $Sdk "cmdline-tools") | Out-Null
  $latest = Join-Path $Sdk "cmdline-tools\latest"
  if (Test-Path $latest) { Remove-Item $latest -Recurse -Force }
  Move-Item (Join-Path $tmp "cmdline-tools") $latest
  Remove-Item $tmp -Recurse -Force; Remove-Item $zip -Force
}
if (-not (Test-Path (Join-Path $Sdk "platforms\android-34")) -or -not (Test-Path (Join-Path $Sdk "build-tools\34.0.0"))) {
  Say "Installing Android SDK 34 (accepting the Android SDK licences)"
  $yes = (1..30 | ForEach-Object { "y" }) -join "`n"
  $yes | & $SdkManager "--sdk_root=$Sdk" --licenses | Out-Null
  & $SdkManager "--sdk_root=$Sdk" "platform-tools" "platforms;android-34" "build-tools;34.0.0"
}
"sdk.dir=$($Sdk -replace '\\','\\')" | Set-Content -Encoding ASCII (Join-Path $Dir "local.properties")

# ---- Gradle ---------------------------------------------------------------
$Gradle = Join-Path $Tools "gradle-$GradleVersion\bin\gradle.bat"
if (-not (Test-Path $Gradle)) {
  Say "Downloading Gradle $GradleVersion"
  $gz = Join-Path $Tools "gradle.zip"
  Invoke-WebRequest "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip" -OutFile $gz
  Expand-Archive $gz -DestinationPath $Tools
  Remove-Item $gz -Force
}

# ---- Build ----------------------------------------------------------------
Say "Building 1Q (first run downloads the Android Gradle Plugin - a few minutes)"
$env:ANDROID_HOME = $Sdk; $env:ANDROID_SDK_ROOT = $Sdk
& $Gradle -p $Dir ":app:assembleRelease" --no-daemon
if ($LASTEXITCODE -ne 0) { Fail "Gradle build failed (see messages above)." }

$Apk = Join-Path $Dir "app\build\outputs\apk\release\app-release.apk"
if (-not (Test-Path $Apk)) { Fail "Build finished but no APK was found." }
Copy-Item $Apk (Join-Path $Dir "1Q.apk") -Force
Write-Host "`nDone: $(Join-Path $Dir '1Q.apk')" -ForegroundColor Green
Write-Host "Copy it to your phone and open it, or with a phone connected run:"
Write-Host "  & `"$(Join-Path $Sdk 'platform-tools\adb.exe')`" install -r `"$(Join-Path $Dir '1Q.apk')`""
